import { Component, TemplateRef, ElementRef, ViewChild, ViewEncapsulation, SecurityContext } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import { DashboardService } from '../dashboard.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { saveAs } from 'file-saver';

export interface ApproveReject {
  id: any;
  tag: any;
  title: any;
  msg: any;
  visible: any;
}

export interface SimpleAlert {
  title: any;
  msg: any;
}

export interface ConfirmAlert {
  id: any;
  title: any;
  msg: any;
}

export interface ViewQuoteDetails {
  ticketData: any;
  quoteData: any;
  partList: any;
  serviceCharge: any;
  total: any;
}

export interface SameUnitRepairData {
  label: string;
  options: any;
}

export interface ServiceData {
  gsxNo: string;
  serviceType: any;
  diagnosis: string;
}

export interface AdditionalDetails {
  accessory: any;
  family: any;
  condition: any;
  upgrade: string;
  serviceType: any;
}

@Component({
  selector: 'app-ticketdetail',
  templateUrl: './ticketdetail.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./ticketdetail.component.scss',
              '../../../../scss/customstyle.css',
             ],
  providers: [ DashboardService],
})

export class TicketdetailComponent {
  /* @ViewChild('fileInput') fileInput: ElementRef;
  @ViewChild('myInput') myInputVariable: ElementRef;
  @ViewChild('myQInput') myQInputVariable: ElementRef; */
  @ViewChild('fileInput', {static: true}) fileInput: ElementRef;
  @ViewChild('myInput', {static: true}) myInputVariable: ElementRef;
  @ViewChild('myQInput', {static: true}) myQInputVariable: ElementRef;
  ticketId;
  loading = true;
  buttonSpin = false;
  isManager;
  error: any;
  isGSXError = false;
  gsxError: any = '';
  onlyView;
  data: any = [];
  dataTemp: any = [];
  technicianId = '';
  technicianList: any = [];
  assignedUserName;
  customerInfo: any = [];
  companyName = '';
  statusOptions: any = [];
  assignees: any = [];
  ruleStatus;
  modalRef: BsModalRef;
  firstName: any = '';
  recentData: any = [];
  timelineData: any = [];
  isToken: any = true;
  isAdvancetab: any = false;
  isInvoicetab: any = false;
  isDevice: any = false;
  isPhysical: any = true;
  productName = '';
  warrantyStatuses: any = [
    {id: '0', name: 'Select Warranty Status'},
    {id: '1', name: 'Apple Limited Warranty'},
    {id: '2', name: 'Out of Warranty(No Coverage)'},
    {id: '3', name: 'Apple Care Production Plan(APP)'},
    {id: '4', name: 'Apple Care Production Plus(AC+)'},
  ];
  warrantyStatus = 'Select Warranty Status';
  physicalLocation;
  physicalError = '';
  physicalMsg = '';
  description: any = null;
  documentTemp: any = [];
  documents: any = [];
  selectedFile: any;
  removeDocOpt = false;
  quoteDocumentTemp: any = [];
  quoteSelectedFile: any;
  bcolor = false;
  dcolor = false;
  qcolor = false;
  qbcolor = false;
  lineColor = false;
  remarks = '';
  releaseRemarks = '';
  branchCode;
  title: string;
  changedata;
  requiredFields = false;
  requiredInputs: any = [];
  optionalFields = false;
  optionalInputs: any = [];
  submitbtn = false;
  optionvalue;
  notfilled = false;
  acceptSpinner = false;
  userRole;
  userID;
  isAccepted = 'false';
  showAssign = false;
  documentType = 'Select document type';
  documentTypes;
  isExDocuments = false;
  isViewDoc = false;
  documentUrl: any;
  dError = '';
  selectedDocument: any = [];
  quotations: any = [];
  isQuoteMac = false;
  quoteTable = [];
  quoteError = '';
  isCreateQuote = 'null'; // 'null' will be the future use.
  diagnosis = '';
  partNo = '';
  partDetails: any = [];
  priceType = 'Select type';
  priceTypes: any = [];
  serviceCharge;
  qError = '';
  quoteId = '';
  quoteLimit = false;
  quoteDocuments: any = [];
  quoteDocumentsTypes: any = [];
  quoteDocumentType = 'Select document type';
  isExQuoteDocuments = false;
  viewPartDetails: ViewQuoteDetails = {ticketData: [], quoteData: [], partList: [], serviceCharge: '', total: ''};
  approveReject: ApproveReject = {id: '', tag: '', title: '', msg: '', visible: 'false'};
  simpleAlert: SimpleAlert = {title: '', msg: ''};
  confirmAlert: ConfirmAlert = {id: '', title: '', msg: ''};
  onsiteEngg: any = [];
  assignReassign: any;
  isService: any = true;
  servicePartInput: any = [{serialNo: '', partNo: '', partDetail: ''}];
  sPartDetails: any = [];
  sameUnitRepairData: SameUnitRepairData = {label: '', options: []};
  serviceData: ServiceData = {gsxNo: '', serviceType: 'N/A', diagnosis: ''};
  additionalDetails: AdditionalDetails = {accessory: '', family: 'Select Family', condition: '', upgrade: '', serviceType: 'Select Type'};
  families: any = [];
  gsxRepairs: any = [];
  showRepairDetails = false;
  serviceTypes: any = [];
  svcUrl: any;
  existSvc: any = [];
  isExistSvc = false;
  svcDiagnosis = '';
  showSVCForm: any = 'false';
  deleteSvcRemarks = '';
  deleteSvcId = '';
  gsxNo: any = '';
  srParts: any = [];
  repairDetails: any = [];
  repairedParts: any = [];
  quoatRefNo: any;
  analysisText: any = '';
  analysisList: any = [];
  damageList: any = [];
  conditionError = '';
  typeofDamage = 'Select the Damage';
  pendingOptions: any = [
      {id: '0', name: 'Select Pending Status'},
      {id: '1', name: 'Apple Pending'},
      {id: '2', name: 'Ample Pending'},
      {id: '3', name: 'Customer Pending'},
    ];
  paymentDetails: any = [];
  paymentAdvance: any = [];
  paymentInvoice: any = [];
  isInvoice = false;
  isAdvance = false;
  ccAnalysisText: any = '';
  ccAnalysisList: any = [];
  EnquiryList: any = [];
  messageList: any = [];
  blueDartResult: any;
  trackData = '' ;
  ticketType = localStorage.getItem('ticket_type');
  isCollapsed = true;
  upArrow = true;
  upAdvArrow = false;
  upInvArrow = false;
  html = '';
  constructor(
    private dataService: DashboardService,
    private modalService: BsModalService,
    public sanitizer: DomSanitizer) {
      this.html = sanitizer.sanitize(SecurityContext.HTML, this.html);
      this.ticketId = localStorage.getItem('id');
      this.userRole = localStorage.getItem('userRole');
      this.userID = localStorage.getItem('userId');
      this.getOptions();
      this.getAssignee();
      this.getdata(this.ticketId);
      this.documentTypes = [
        {id: '0', name: 'Select document type'},
        {id: '1', name: 'Aadhar'},
        {id: '2', name: 'Driving License'},
        {id: '3', name: 'PAN Card'},
        {id: '4', name: 'Other'}
       ];
       this.quoteDocumentsTypes = [
        {id: '0', name: 'Select document type'},
        {id: '1', name: 'Quotation'},
        {id: '2', name: 'Purchase Order'},
        {id: '3', name: 'Delivery Check (DC)'}
       ];
       this.damageList = [
        {id: '0', name: 'Select the Damage'},
        {id: '1', name: 'Physical Damage'},
        {id: '2', name: 'Liquid Damage'}
       ];
       this.families = [{id: '0', name: 'Select Family'}, {id: '1', name: 'Accessory'}, {id: '2', name: 'Apple TV'},
                    {id: '3', name: 'Apple Watch'}, {id: '4', name: 'Beats'}, {id: '5', name: 'Desktop & Portables'},
                    {id: '6', name: 'iPad'}, {id: '7', name: 'iPhone'}, {id: '8', name: 'iPod'}, {id: '9', name: 'Mac'}];
        this.serviceTypes = [{id: '0', name: 'Select Type'}, {id: '1', name: 'Chargeable - C'}, {id: '2', name: 'Warranty - W'},
                            {id: '3', name: 'Yet to determine'}];
      this.getQuotation(this.ticketId);
      this.partNo = '';
    }

  collapsed(event: any): void {
  }

  expanded(event: any): void {
  }

  collapse() {
    if (this.upArrow) {
      this.upArrow = false;
      this.isCollapsed = !this.isCollapsed;
    } else {
      this.upArrow = true;
      this.isCollapsed = !this.isCollapsed;
    }
  }

  paymentAdvFun() {
    if (this.upAdvArrow) {
      this.upAdvArrow = false;
      this.isAdvancetab = !this.isAdvancetab;
    } else {
      this.upAdvArrow = true;
      this.isAdvancetab = !this.isAdvancetab;
    }
  }

  paymentInvFun() {
    if (this.upInvArrow) {
      this.upInvArrow = false;
      this.isInvoicetab = !this.isInvoicetab;
    } else {
      this.upInvArrow = true;
      this.isInvoicetab = !this.isInvoicetab;
    }
  }

  getOptions() {
    this.dataService.getOptions()
      .subscribe(
        (data) => {
            this.statusOptions = data;
        }, // success path
        error => this.error = error // error path
      );
  }

  getdata(ticket_id) {
    this.dataService.getDetail(ticket_id)
        .subscribe(
          (data) => {
              this.dataTemp = data;
              this.dataTemp = this.dataTemp.tickets[0];
              this.data = this.dataTemp;
              this.title = this.data.problem_reported;
              if (this.title.length > 100) {
                this.title = this.title.slice(0, 150);
                this.title = this.title + '...';
              }
              this.ticketId = '';
              this.ticketId = this.data.id;
              this.quoatRefNo = this.data.quotation_ref_no;
              this.checkTicket();
              this.getQuotation(this.ticketId);
              this.getSVC(this.ticketId);
              this.gettimelinedata(this.ticketId);
              this.getDocuments(this.ticketId);
              this.getAnalysis(this.ticketId);
              this.ccGetAnalysis(this.ticketId);
              this.getEnquiry(this.ticketId);
              this.getMessage(this.ticketId);
              this.getPaymentDetails();
              this.loading = false;
              if (this.data.product_family === 'Mac' ) {
                this.isQuoteMac = true;
              } else {
                this.isQuoteMac = false;
              }
              if (this.data.product_description === '*****') {
                this.productName = '';
              } else {
                this.productName = this.data.product_description;
              }
              if (this.data.warranty_status === '*****') {
                this.warrantyStatus = 'Select Warranty Status';
              } else {
                this.warrantyStatus = this.data.warranty_status;
              }
              if (this.data.quotation_new_flag === 'Y') {
                this.isCreateQuote = 'false';
              } else {
                this.isCreateQuote = 'null';
              }
              if (this.data.site_type_id === '2') {
                this.isDevice = false;
                this.getCustomerInfo(this.data.customer_id);
              } else if (this.data.site_type_id === '1') {
                this.getCustomerInfo(this.data.customer_id);
              }
              if (this.data.pending_type === '') {
                this.data.pending_type = 'Select Pending Status';
              }
              if (this.data.g_number === '') {
                this.serviceData = {gsxNo: '', serviceType: 'Select Value', diagnosis: ''};
              } else {
                this.gsxNo = this.data.g_number;
                this.serviceData = {gsxNo: this.data.g_number, serviceType: 'Select Value', diagnosis: ''};
              }
          this.html = this.html + '<span>' + 'Token No' + '&nbsp;' + '-' + '&nbsp;' + this.data.token_no + '</span><br/>' + '<span>' + 'Family' + '&nbsp;' + '-' + '&nbsp;' + this.data.product_family + '</span><br/>'  + '<span>' + 'Product' + '&nbsp;' + '-' + '&nbsp;' + this.data.product_category + '</span><br/>';

          }, // success path
          error => this.error = error // error path
        );
  }

  recentUpdate(recent_update_temp: TemplateRef<any>) {
    this.openModal(recent_update_temp);
  }

  navigateTo(nav_to) {
    this.dataService.navigateTo(this.ticketId, this.data.branch_code, nav_to)
      .subscribe(
        (data) => {
          this.dataTemp = data;
          if (this.dataTemp.status === true) {
            this.dataTemp = this.dataTemp.tickets[0];
            this.data = this.dataTemp;
            this.title = this.data.problem_reported;
            if (this.title.length > 100) {
              this.title = this.title.slice(0, 150);
              this.title = this.title + '...';
            }
            // this.data.problem_reported.
            this.ticketId = '';
            this.ticketId = this.data.id;
            this.quoatRefNo = this.data.quotation_ref_no;
            this.getAssignee();
            this.gettimelinedata(this.ticketId);
            this.getDocuments(this.ticketId);
            this.getQuotation(this.ticketId);
            this.getSVC(this.ticketId);
            this.checkTicket();
            this.getAnalysis(this.ticketId);
            this.ccGetAnalysis(this.ticketId);
            this.getEnquiry(this.ticketId);
            this.getMessage(this.ticketId);
            this.getPaymentDetails();
            if (this.data.product_family === 'Mac' ) {
              this.isQuoteMac = true;
            } else {
              this.isQuoteMac = false;
            }
            if (this.data.product_description === '*****') {
              this.productName = '';
            } else {
              this.productName = this.data.product_description;
            }
            if (this.data.warranty_status === '*****') {
              this.warrantyStatus = 'Select Warranty Status';
            } else {
              this.warrantyStatus = this.data.warranty_status;
            }
            if (this.data.quotation_new_flag === 'Y') {
              this.isCreateQuote = 'false';
            } else {
              this.isCreateQuote = 'null';
            }
            if (this.data.site_type_id === '2') {
              this.isDevice = false;
              if (this.userRole !== '6') {
                this.data.site_type_id = null;
              }
              this.getCustomerInfo(this.data.company_id);
            } else if (this.data.site_type_id === '1') {
              this.getCustomerInfo(this.data.customer_id);
            }

            if (this.data.pending_type === '') {
              this.data.pending_type = 'Select Pending Status';
            }
            if (this.data.g_number === '') {
              this.serviceData = {gsxNo: '', serviceType: 'Select Value', diagnosis: ''};
            } else {
              // this.GSXParts(this.data.g_number);
              this.gsxNo = this.data.g_number;
              this.serviceData = {gsxNo: this.data.g_number, serviceType: 'Select Value', diagnosis: ''};
            }
          }
          this.quoteError = '';
        }, // success path
        error => this.error = error // error path
    );
  }

  getCustomerInfo(id) {
    let result: any;
    this.dataService.getCustomerInfo(id, this.data.customer_phone_no)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.customerInfo = result.customer;
                  this.customerInfo.address = this.customerInfo.address1 + '\n' + this.customerInfo.address2 + '\n' +
                                              this.customerInfo.city + '\n' + this.customerInfo.state + '\n' + this.customerInfo.pin;
                }
    });
    if (this.data.site_type_id === '2') {
      let result: any;
      this.dataService.getCompany(this.ticketId)
              .subscribe(
                (data) => {
                  result = data;
                  if (result.status === true) {
                    this.companyName = result.company.company.company_name;
                  }
      });
    }
  }

  checkTicket() {
    if ((this.data.assigned_user_id === '0')) {
      const temp: any = [{user_name: 'unassigned', user_id: '0'}];
      this.technicianList = Array.prototype.concat.apply([], [temp, this.assignees]);
      for (let i = 0; i < this.technicianList.length; i++) {
        if (this.data.assigned_user_id === this.technicianList[i].user_id) {
          this.assignedUserName = this.technicianList[i].user_name;
        }
      }
      this.isAccepted = 'false';
      this.isViewDoc = false;
      this.showAssign = false;
    } else if (this.data.assigned_user_id === this.userID) {
      const temp: any = [{user_name: 'unassigned', user_id: '0'}];
      this.technicianList = Array.prototype.concat.apply([], [temp, this.assignees]);
      for (let i = 0; i < this.technicianList.length; i++) {
        if (this.data.assigned_user_id === this.technicianList[i].user_id) {
          this.assignedUserName = this.technicianList[i].user_name;
        }
      }
      this.isAccepted = 'true';
      this.isViewDoc = true;
      this.showAssign = true;
    } else {
      const temp: any = [{user_name: 'unassigned', user_id: '0'}];
      this.technicianList = Array.prototype.concat.apply([], [temp, this.assignees]);
      for (let i = 0; i < this.technicianList.length; i++) {
        if (this.data.assigned_user_id === this.technicianList[i].user_id) {
          this.assignedUserName = this.technicianList[i].user_name;
        }
      }
      this.isAccepted = 'null';
      this.isViewDoc = false;
      this.showAssign = false;
    } // Assigned Used

    if ((this.userRole === '6') || (this.userRole === '8')) {
      this.showAssign = true;
      this.isViewDoc = true;
    }

    if ((this.ticketType === 'enquiry') || (this.data.assigned_user_id === this.userID)) {
      this.isViewDoc = true;
    }

    if ((this.userRole === '3') || (this.userRole === '2')) {
      this.isManager = false;
    } else {
      this.isManager = true;
    }

    if ((this.userRole === '9') || (this.userRole === '10') || (this.userRole === '11') ||
    (this.userRole === '13') || (this.userRole === '14') || (this.userRole === '15')) {
      this.onlyView = true;
    } else {
      this.onlyView = false;
    }

    if (this.data.site_type_id === '2') {
      this.data.enquiry_flag = 'Y';
      if (this.data.assigned_user_id !== '0') {
        this.assignReassign = 'Re-Assign';
      } else {
        this.assignReassign = 'Assign';
      }
      this.sameUnitRepairData = {label: 'Is SUR ( Same Unit Repair ) ?', options: [{id: '1', name: 'Yes'}, {id: '2', name: 'No'}]};
      this.serviceData = {gsxNo: '', serviceType: 'Select', diagnosis: ''};
    } else {
      this.sameUnitRepairData = {label: 'Is SUR/WUR/NA (Same Unit Repair/Whole Unit Repair/Not Applicable)?',
                                options: [{id: '1', name: 'N/A'}, {id: '2', name: 'SUR'},
                                {id: '3', name: 'WUR'}]};
      this.serviceData = {gsxNo: '', serviceType: 'N/A', diagnosis: ''};
      this.serviceData.serviceType = 'Select';
    }
  }

  acceptTicket(simple_alert_temp: TemplateRef<any>) {
    this.dataService.acceptTicket(this.ticketId)
      .subscribe(
        (data) => {
            this.acceptSpinner = true;
            const result: any = data;
            setTimeout(() => {
              if (result.status === true) {
                // this.getAssignee();
                this.getdata(this.ticketId);
                this.acceptSpinner = false;
              } else {
                this.simpleAlert = {title: 'Accept Ticket', msg: result.message};
                this.acceptSpinner = false;
                this.openModal(simple_alert_temp);
            }
            }, 2000);
        }, // success path
        error => this.error = error // error path
      );
  }

  release(ticket_release_temp: TemplateRef<any>) {
    this.acceptSpinner = true;
    this.openModal(ticket_release_temp);
  }

  releaseTicket(simple_alert_temp: TemplateRef<any>) {
    if (this.releaseRemarks === '') {
      this.notfilled = true;
      this.acceptSpinner = false;
    } else {
      this.acceptSpinner = true;
      this.modalRef.hide();
      this.dataService.releaseTicket(this.ticketId, this.releaseRemarks)
      .subscribe(
        (data) => {
          const result: any = data;
            if (result.status === true) {
              // this.getAssignee();
              this.getdata(this.ticketId);
              this.releaseRemarks = '';
              this.acceptSpinner = false;
            } else {
              this.simpleAlert = {title: 'Release Ticket', msg: result.message};
              this.acceptSpinner = false;
              this.releaseRemarks = '';
              this.openModal(simple_alert_temp);
            }
        }, // success path
        error => this.error = error // error path
      );
      this.notfilled = false;
    }

  }

  getAssignee() {
    this.dataService.getAssignees()
      .subscribe(
        (data) => {
            const assigneeData: any = data;
            this.assignees = assigneeData.user;
        }, // success path
        error => this.error = error // error path
      );
  }

  selectTechnician(value, confirm_alert_temp: TemplateRef<any>) {
    for (let i = 0; i < this.technicianList.length; i++) {
      if (value === this.technicianList[i].user_name) {
        this.technicianId = this.technicianList[i].user_id;
      }
    }
    const msg = 'Are you sure want to assign this ticket to ' + value;
    this.confirmAlert = {id: 'serviceAssign', title: 'Assign Ticket', msg: msg};
    this.openModal(confirm_alert_temp);
  }

  getOnsiteEnggs(assignee_list_temp: TemplateRef<any>) {
    let result: any;
    this.dataService.getOnsiteEnggs(this.data.site_type_id)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.onsiteEngg = result.users;
                }
    });
    this.openModal(assignee_list_temp);
  }

  selectEngg(engg, confirm_alert_temp: TemplateRef<any>) {
    this.modalRef.hide();
    const msg = 'Are you sure want to assign this ticket to ' + engg.user_name;
    this.confirmAlert = {id: engg.user_id, title: 'Assign Ticket', msg: msg};
    this.openModal(confirm_alert_temp);
  }

  confirm(inputdata, simple_alert_temp: TemplateRef<any>, create_svc_temp: TemplateRef<any>) {
    let result: any;
    if (inputdata === '00') {
      this.dataService.deleteDocument(this.selectedDocument.doc_id, this.selectedDocument.doc_tid)
        .subscribe(
          (data) => {
            result = data;
            if (result.status === true) {
              this.getDocuments(this.ticketId);
            } else {
              this.simpleAlert = {title: 'Delete Document', msg: result.message};
              this.openModal(simple_alert_temp);
            }
          }, // success path
        error => this.error = error // error path
      );
      this.modalRef.hide();
    } else if (inputdata === 'SVC') {
      this.showSVCForm = 'true';
      this.gsxNo = '';
      this.modalRef.hide();
      this.openModal(create_svc_temp);
    } else if (inputdata === 'serviceAssign') {
      this.dataService.assignTicket(this.ticketId, this.technicianId)
        .subscribe(
          (data) => {
            result = data;
            if (result.status === true) {
              this.getdata(this.ticketId);
            } else {
              this.simpleAlert = {title: 'Assign Ticket', msg: result.message};
              this.openModal(simple_alert_temp);
            }
          }, // success path
        error => this.error = error // error path
      );
      this.modalRef.hide();
    } else {
      this.dataService.assign_call(this.ticketId, inputdata)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.modalRef.hide();
                  this.simpleAlert = {title: 'Assign Ticket', msg: result.message};
                  this.assignReassign = 'Re-Assign';
                  this.getdata(this.ticketId);
                  this.openModal(simple_alert_temp);
                } else {
                  this.modalRef.hide();
                  this.simpleAlert = {title: 'Assign Ticket', msg: result.message};
                  this.getdata(this.ticketId);
                  this.openModal(simple_alert_temp);
                }
        });
    }
  }

  openModal(templat) {
    this.modalRef = this.modalService.show(templat, { backdrop: 'static', keyboard: false });
    this.buttonSpin = false;
  }

  cancelModel() {
    this.modalRef.hide();
    this.partDetails = [];
  }

  updateProductName() {
    if (this.productName !== '') {
      this.buttonSpin = true;
      let result: any;
      this.dataService.updateProductName(this.ticketId, this.productName)
              .subscribe(
                (data) => {
                  result = data;
                  this.buttonSpin = false;
                  if (result.status === true) {
                    this.getdata(this.ticketId);
                  }
              });
    }
  }

  updateWarrantyStatus() {
    if (this.warrantyStatus !== 'Select Warranty Status') {
      this.buttonSpin = true;
      let result: any;
      this.dataService.updateWarrantyStatus(this.ticketId, this.warrantyStatus)
              .subscribe(
                (data) => {
                  result = data;
                  this.buttonSpin = false;
                  if (result.status === true) {
                    this.getdata(this.ticketId);
                  }
              });
    }
  }

  checkPhysicalLocation() {
    if (this.physicalLocation !== null) {
      this.buttonSpin = true;
      let result: any;
      this.dataService.checkPhysicalLocation(this.ticketId, this.physicalLocation, this.data.branch_code, this.data.product_family)
              .subscribe(
                (data) => {
                  result = data;
                  if (result.status === true) {
                    this.buttonSpin = false;
                    this.physicalMsg = result.message;
                    setTimeout(() => {
                      this.physicalError = '';
                      this.getdata(this.ticketId);
                    }, 3000);
                  } else {
                    this.buttonSpin = false;
                    this.physicalError = result.message;
                    setTimeout(() => {
                      this.physicalError = '';
                    }, 3000);
                  }
              });
    }
  }

  deviceCondition() {
    if (this.typeofDamage !== 'Select the Damage') {
      this.buttonSpin = true;
      let result: any;
      this.dataService.conditionDevice(this.ticketId, this.typeofDamage)
              .subscribe(
                (data) => {
                  result = data;
                  if (result.status === true) {
                    this.data.condition_of_device = this.typeofDamage;
                  } else {
                    this.buttonSpin = false;
                    this.conditionError = result.message;
                    setTimeout(() => {
                      this.conditionError = '';
                    }, 3000);
                  }
              });
    }
  }

  /*********** Status Change ***********/
  stateonChange( id, optidx, template: TemplateRef<any>,  simple_alert_temp: TemplateRef<any>) {
    this.optionvalue = optidx;
    this.requiredInputs = [];
    this.optionalInputs = [];
    this.remarks = '';
        for (let j = 0; j < this.statusOptions.status.length; j++) {
          if (this.statusOptions.status[j].value === optidx) {
this.changedata = '&source_status=' + this.data.status_id + '&destination_status=' + this.statusOptions.status[j].id + '&ticket_id=' + id;
            this.dataService.checkRules(this.changedata)
            .subscribe(
              (data) => {
                  this.ruleStatus = data;
                  if (this.ruleStatus.status === false) { // Rule Status is False
                    if (this.ruleStatus.required_fields.length !== 0) {
                        for (let k = 0; k < this.ruleStatus.required_fields.length; k++) {
                            if (this.ruleStatus.mandatory[k] === 'Y') {
                              this.requiredInputs.push({
                                label : this.ruleStatus.required_fields[k],
                                input : ''
                              });
                            } else {
                              this.optionalInputs.push({
                                label : this.ruleStatus.required_fields[k],
                                input : ''
                              });
                            }
                        }
                      this.optionalFields = true;
                      this.requiredFields = true;
                      this.submitbtn = true;
                      this.openModal(template);
                    } else {
                      this.simpleAlert = {title: 'Status Update', msg:  this.ruleStatus.message};
                      this.getdata(this.ticketId);
                      this.openModal(simple_alert_temp);
                      this.requiredFields = false;
                      this.optionalFields = false;
                    }
                  } else { // Rule Status is True
                    this.openModal(template);
                    this.requiredFields = false;
                    this.optionalFields = false;
                    this.submitbtn = true;
                  }
              }, // success path
              error => this.error = error // error path
            );
          }
        }
  }

  submit(requiredInput, optionalInput) {
    let isFilled: any = true;
    if (this.requiredFields === false) {
      if (this.remarks !== '') {
      this.callUpdate(requiredInput);
      } else {
        this.notfilled = true;
      }
    } else {
        for (let i = 0; i < this.requiredInputs.length; i++) {
          if (requiredInput[i].input === '') {
            isFilled = false;
          }
        }
        if (isFilled === true && this.remarks !== '') {
          requiredInput = Array.from(new Set(requiredInput.concat(optionalInput)));
          this.callUpdate(requiredInput);
        } else {
          this.notfilled = true;
        }
    }
  }

  pendingChange(value) {
    this.dataService.updatePendingStatus(this.ticketId, value)
    .subscribe(
      (data) => {
        const result: any = data;
        if (result.status === true) {
          this.getdata(this.ticketId);
        } else {
          alert(result.message);
        }
      }, // success path
      error => this.error = error // error path
    );
  }

  callUpdate(filledinput) {
    let finalData = [];
    for (let i = 0; i < filledinput.length; i++) {
      if (filledinput[i].label === 'G Number') {
        filledinput.push({
          label : 'N Number',
          input : '0',
        });
        finalData = filledinput;
        break;
      } else if (filledinput[i].label === 'N Number') {
        finalData.push({
          label : 'G Number',
          input : '0',
        },
        {
          label : 'Case Id',
          input : '0',
        },
        {
          label : 'N Number',
          input : filledinput[i].input,
        }
        );
        break;
      }
    }
    this.dataService.statusUpdate(this.changedata, this.remarks, finalData)
    .subscribe(
      (data) => {
        const result: any = data;
        if (result.status === true) {
            this.getdata(this.ticketId);
            this.modalRef.hide();
            this.remarks = '';
            this.requiredInputs = [];
            if (this.data.quotation_new_flag === 'Y') {
              this.isCreateQuote = 'false';
            } else {
              this.isCreateQuote = 'null';
            }
        } else if (result.status === 'truefalse') {
          this.getdata(this.ticketId);
            this.modalRef.hide();
            this.remarks = '';
            this.requiredInputs = [];
            if (this.data.quotation_new_flag === 'Y') {
              this.isCreateQuote = 'false';
            } else {
              this.isCreateQuote = 'null';
            }
            alert(result.message);
        } else {
            this.ruleStatus = data;
            this.submitbtn = false;
            this.getdata(this.ticketId);
            this.remarks = '';
            this.requiredInputs = [];
        }
      }, // success path
      error => this.error = error // error path
    );
  }

  cancel() {
    this.modalRef.hide();
    this.acceptSpinner = false;
    this.requiredInputs = [];
    this.optionalInputs = [];
    this.notfilled = false;
    const tempstate = this.dataTemp.status_name;
    this.data.status = tempstate;
    this.data.statusclr = this.dataTemp.statusclr;
  }

  updateCustomer() {

  }

  /* ******************* Time Line Data ******************* */
  gettimelinedata(ticketId) {
    this.dataService.timelineData(ticketId)
        .subscribe(
          (data) => {
            this.timelineData = data;
            if (this.timelineData.status !== 'false') {
              this.recentData = this.timelineData.timeline;
            } else {
              this.recentData = [];
            }
          }, // success path
          error => this.error = error // error path
        );
  }

  /* ******************* Documents ******************* */
  getDocuments(ticketId) {
    let result: any = [];
    let qdocs: any = [];
    let docs: any = [];
    this.quoteDocuments = [];
    this.documents = [];
    this.dataService.getDocuments(ticketId)
      .subscribe(
        (data) => {
          result = data;
          if (result.length === 0) {
            this.isExDocuments = false;
          } else {
            for (let i = 0; i < result.length; i++) {
              if ((result[i].document_type === 'Quotation') || (result[i].document_type === 'Purchase Order')) {
                qdocs = result[i];
                this.quoteDocuments = Array.prototype.concat.apply([], [qdocs, this.quoteDocuments]);
                this.isExQuoteDocuments = true;
              } else {
                docs = result[i];
                this.documents = Array.prototype.concat.apply([], [docs, this.documents]);
                this.isExDocuments = true;
              }
            }

            for (let j = 0; j < result.length; j++) {
              if ((result[j].document_type === 'customer_pop') || (result[j].document_type === 'customer_id')) {
                this.documents[j].removeDocOpt = false;
              } else {
                this.documents[j].removeDocOpt = true;
              }
            }
          }
          this.documentType = 'Select document type';
        }, // success path
        error => this.error = error // error path
      );
  }

  onFileUpload(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files[0]) {
     this.documentTemp = event.target.files[0];
     reader.readAsDataURL(this.documentTemp);
     reader.onload = () => { // called once readAsDataURL is completed
     this.selectedFile = reader.result;
     this.dcolor = false;
    };
    }
  }

  upload(desc) {
    this.buttonSpin = true;
    const today = new Date().toDateString();
    const docs: any = [];
      if (this.documentType !== 'Select document type') {
        this.bcolor = false;
      } else {
        this.bcolor = true;
      }
      if (this.documentTemp.length !== 0) {
        docs.push({
          document_type: this.documentType,
          file_name: this.documentTemp.name,
          extension: this.documentTemp.type.split('/')[1],
          date: today,
          file: this.selectedFile,
          description: encodeURIComponent(desc)
        });
      } else {
        this.dcolor = true;
      }

      if (this.dcolor === false && this.bcolor === false) {
        if (this.documentTemp.size <= 5000000) {
          this.dataService.uploadDocuments(this.ticketId, docs)
              .subscribe(
                (data) => {
                  this.documentTemp = [];
                  this.documentType = 'Select document type';
                  this.getDocuments(this.ticketId);
                  this.buttonSpin = false;
                  this.dError = '';
                }, // success path
              error => this.error = error // error path
            );
            this.description = null;
            this.myInputVariable.nativeElement.value = '';
            this.dcolor = false;
        } else {
          this.dError = 'File size should be less than 5MB';
          this.buttonSpin = false;
        }
      } else {
        this.buttonSpin = false;
      }
  }

  removeDoc(doc, confirm_alert_temp: TemplateRef<any>) {
    this.selectedDocument = {doc_id: doc.id, doc_tid: doc.ticket_id};
    const msg = 'Are you sure want to delete this document?';
    this.confirmAlert = {id: '00', title: 'Delete Document', msg: msg};
    this.openModal(confirm_alert_temp);
  }

  downloadDoc(doc) {
    const docName: string = doc.document_type + '.' + doc.extension;
    saveAs(doc.file_name, docName);
  }

  /* ******************* Notifications ******************* */
  emailmodel(status_change_temp: TemplateRef<any>) {
    console.log('email temp');
    this.openModal(status_change_temp);
  }

  /* ******************* Quotation ******************* */
  quoatRefNoUpdate(simple_alert_temp: TemplateRef<any>) {
    let result: any;
    this.dataService.quotationRefUpdate(this.ticketId, this.quoatRefNo)
    .subscribe(
      (data) => {
        result = data;
        if (result.status === true) {
          this.simpleAlert = {title: 'Quotation', msg: 'Reference number updated successfully.'};
          this.openModal(simple_alert_temp);
          this.getdata(this.ticketId);
        }
      }, // success path
      error => this.error = error // error path
    );
  }

  onQuoteFileUpload(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files[0]) {
     this.quoteDocumentTemp = event.target.files[0];
     reader.readAsDataURL(this.quoteDocumentTemp);
     reader.onload = () => { // called once readAsDataURL is completed
     this.selectedFile = reader.result;
     this.qcolor = false;
    };
    }
  }

  quoteupload(desc) {
    this.buttonSpin = true;
    const today = new Date().toDateString();
    const docs: any = [];
      if (this.quoteDocumentType !== 'Select document type') {
        this.qbcolor = false;
      } else {
        this.qbcolor = true;
      }

      if (this.quoteDocumentTemp.length !== 0) {
        docs.push({
          document_type: this.quoteDocumentType,
          file_name: this.quoteDocumentTemp.name,
          extension: this.quoteDocumentTemp.type.split('/')[1],
          date: today,
          file: this.selectedFile,
          description: desc
        });
      } else {
        this.qcolor = true;
      }

      if (this.dcolor === false && this.bcolor === false) {
        if (this.quoteDocumentTemp.size <= 5000000) {
          this.dataService.uploadDocuments(this.ticketId, docs)
            .subscribe(
              (data) => {
                this.quoteDocumentTemp = [];
                this.quoteDocumentType = 'Select document type';
                this.getDocuments(this.ticketId);
                this.buttonSpin = false;
                this.qError = '';
              }, // success path
            error => this.error = error // error path
          );
          this.myQInputVariable.nativeElement.value = '';
          this.dcolor = false;
        } else {
          this.qError = 'File size should be less than 5MB';
          this.buttonSpin = false;
        }
      } else {
        this.buttonSpin = false;
      }
  }

  createQuoteTemp(create_quote_temp: TemplateRef<any>) {
    this.partDetails = [];
    this.isCreateQuote = 'true';
    this.checkProduct();
    this.openModal(create_quote_temp);
  }

  getQuotation(id) {
    this.dataService.getQuotation(id)
        .subscribe(
          (data) => {
            this.quotations = data;
            if (this.quotations.status === true) {
              this.quotations = this.quotations.quotations;
            }
          }, // success path
        error => this.error = error // error path
    );
  }

  checkUserRole(qid) {
    if (this.userRole === '2' || this.userRole === '3') {
      for (let i = 0; i < this.quotations.length; i++) {
        if ((this.quotations[i].id === qid) && (this.quotations[i].status === 'Pending')) {
          this.approveReject = {id: '', tag: '', title: '', msg: '', visible: 'true'};
        } else {
          this.approveReject = {id: '', tag: '', title: '', msg: '', visible: 'false'};
        }
      }
    } else {
      this.approveReject = {id: '', tag: '', title: '', msg: '', visible: 'false'};
    }
  }

  checkProduct() {
    if (this.isQuoteMac === true) {
      this.quoteTable = [{
        head1: 'Part Numer',
        head2: 'Part Description',
        head4: 'Stock Price/Exchange Price in (₹)',
        }];
        // head3: '',
    } else {
      this.quoteTable = [{
                            head1: 'Part Numer',
                            head2: 'Part Description',
                            head4: 'MRP in (₹) Exchange'
                            }];
                            // head3: 'Price Type',

      this.priceTypes = [
                          {id: '0', name: 'Select type'},
                          {id: '1', name: 'Stock Price'},
                          {id: '2', name: 'Exchange Price'}
                        ];
    }
  }

  createQuote() {
    this.partDetails = [];
    this.isCreateQuote = 'true';
    this.checkProduct();
  }

  addPart(event, part_no) {
    let partPrice: any = [];
    if ((event.keyCode === 13) || (event.keyCode === 9)) {
      if (this.partDetails.length < 5) {
        this.dataService.getPartPrice(part_no)
      .subscribe(
        (data) => {
          partPrice = data;
          if (partPrice.status === true) {
            partPrice = partPrice.price[0];
            partPrice.price_type = 'Select type';
            this.partDetails.push(partPrice);
         // this.partDetails[idx].price_type = 'Select type';
          this.partNo = '';
          this.quoteError = '';
          } else {
            this.quoteError = partPrice.message; /*  + 'of' + this.userPartData.part_no */
            this.partNo = '';
          }
        }, // success path
      error => this.error = error // error path
      );
      } else {
        this.quoteLimit = true;
        this.quoteError = 'Maximum limit of Parts been added';
      }
    }
  }

  removePart(idx) {
    this.partDetails.splice(idx, 1);
    this.quoteError = '';
    this.quoteLimit = false;
    this.partNo = '';
  }

  priceonChange(simple_alert_temp: TemplateRef<any>, index) {
    if (this.partDetails[index].price_type === 'Stock Price') {
      this.simpleAlert = {title: 'For Stock Price', msg: 'Please contact to Karan - 9686685468'};
      this.openModal(simple_alert_temp);
      this.partDetails[index].price_type = 'Stock Price';
      this.quoteError = '';
    } else if (this.partDetails[index].price_type === 'Exchange Price') {
      this.partDetails[index].price_type = 'Exchange Price';
      this.quoteError = '';
    }
  }

  generateQuote(simple_alert_temp: TemplateRef<any>) {
    this.buttonSpin = true;
    if (this.serviceCharge === '') {
      this.serviceCharge = 0.00;
    }
    const commonData = '&ticket_id=' + this.ticketId + '&user_id=' + localStorage.getItem('userId') + '&diagnosis=' +
    encodeURIComponent(this.diagnosis) + '&service_charge=' + this.serviceCharge + '&status_id=' + this.data.status_id;
    /* if (this.isQuoteMac === true) {
      this.quoteError = '';
    } else {
      for (let i = 0; i < this.partDetails.length; i++) {
        if (this.partDetails[i].price_type === 'Select type') {
          this.quoteError = 'Select Price Type';
        }
      }
    } */
    if (this.partDetails.length !== 0) {
      if (this.quoteError === '') {
        this.dataService.generateQuotation(commonData, this.partDetails)
        .subscribe(
          (data) => {
            let result: any;
            result = data;
            if (result.status === true) {
              this.getdata(this.ticketId);
              this.isCreateQuote = 'false';
              this.quoteError = '';
              this.buttonSpin = false;
            } else {
              this.buttonSpin = false;
              this.simpleAlert = {title: 'Quotation', msg: result.message};
              this.openModal(simple_alert_temp);
            }
          }, // success path
        error => this.error = error // error path
        );
      }
    } else {
      this.buttonSpin = false;
      this.quoteError = 'Atleast one Part is required to generate the Quote';
    }
  }

  cancelQuote() {
    this.isCreateQuote = 'false';
    this.partDetails = [];
    this.bcolor = false;
    this.serviceCharge = '';
    this.diagnosis = '';
    this.priceType = 'Select type';
    this.buttonSpin = false;
    this.quoteLimit = false;
    this.quoteError = '';
  }

  viewQuote(qid, view_quote_temp: TemplateRef<any>) {
    this.buttonSpin = true;
    this.quoteId = qid;
    this.checkProduct();
    this.checkUserRole(qid);
    let result: any;
    this.dataService.viewQuotation(this.ticketId, qid)
    .subscribe(
      (data) => {
        result = data;
        if (result.status === true) {
          let serviceCharge: any;
          serviceCharge = (result[0].quote_hd[0].service_charge) * ((result[0].quote_hd[0].service_tax / 100) + 1);
          serviceCharge = parseFloat(serviceCharge).toFixed(2);
          const total = parseFloat(result[0].total).toFixed(2);
          this.viewPartDetails = {ticketData: result[0].ticket, quoteData: result[0].quote_hd[0],
                                  partList: result[0].quote_dt, serviceCharge: serviceCharge, total: total};
          this.openModal(view_quote_temp);
        } else {
        }
      }, // success path
    error => this.error = error // error path
    );
  }

  approveRejectQuote(temp, app_rej_temp: TemplateRef<any>) {
    this.modalRef.hide();
    if (temp === 'A') {
      this.approveReject = {id: this.quoteId, tag: 'A', title: 'Approve Quotation',
                            msg: 'Do you want Approve this Quotation?', visible: this.approveReject.visible};
      this.openModal(app_rej_temp);
    } else if (temp === 'R') {
      this.approveReject = {id: this.quoteId, tag: 'R', title: 'Reject Quotation',
                            msg: 'Do you want Reject this Quotation?', visible: this.approveReject.visible};
      this.openModal(app_rej_temp);
    }
  }

  approveRejectSubmit(simple_alert_temp: TemplateRef<any>) {
    let result: any;
    this.dataService.approveRejectQuote(this.ticketId, this.approveReject, this.data.status_id)
    .subscribe(
      (data) => {
        result = data;
        if (result.status === true) {
          this.getdata(this.ticketId);
          this.diagnosis = '';
          this.serviceCharge = '';
          this.modalRef.hide();
          this.simpleAlert = {title: this.approveReject.title, msg: result.message};
          this.getdata(this.ticketId);
          this.openModal(simple_alert_temp);
          this.approveReject = {id: '', tag: '', title: '', msg: '', visible: 'false'};
        } else {
          this.modalRef.hide();
          this.diagnosis = '';
          this.serviceCharge = '';
          this.simpleAlert = {title: this.approveReject.title, msg: result.message};
          this.getdata(this.ticketId);
          this.openModal(simple_alert_temp);
        }
      }, // success path
    error => this.error = error // error path
    );
  }

  resendQuote(qid, simple_alert_temp: TemplateRef<any>) {
    let result;
    this.dataService.resendQuotation(this.ticketId, qid)
            .subscribe(
              data => {
                result = data;
                this.modalRef.hide();
                if (result.status === true) {
                  this.simpleAlert = {title: 'Quotation', msg: result.message};
                  this.openModal(simple_alert_temp);
                } else {
                  this.simpleAlert = {title: 'Quotation', msg: result.message};
                  this.openModal(simple_alert_temp);
                }
              });
  }

  downloadQuote(qid, simple_alert_temp: TemplateRef<any>) {
    const tab = window.open();
    this.dataService.downloadQuotation(this.ticketId, qid)
            .subscribe(
              data => {
                  const fileUrl = URL.createObjectURL(data);
                  tab.location.href = fileUrl;
              });
  }

  /* ******************* GSX Repair ******************* */
  getRepair(simple_alert_temp: TemplateRef<any>) {
    let result;
    this.dataService.getRepairDetail(this.data.g_number, this.ticketId)
      .subscribe(
        data => {
          result = data;
          if (result.status === true) {
            this.showRepairDetails = true;
            this.gsxRepairs = result.gsx_response;
            // console.log(this.gsxRepairs);
this.gsxRepairs.repairCreatedOnDate = new Date(this.gsxRepairs.repairCreatedOnDate).toLocaleString();
            this.gsxRepairs.dt = this.gsxRepairs.parts;
          } else {
            this.simpleAlert = {title: 'GSX Repair', msg: result.message};
            this.openModal(simple_alert_temp);
          }
        });
    /* this.dataService.getRepair(this.data.g_number, this.ticketId)
            .subscribe(
              data => {
                result = data;
                if (result.status === true) {
                  this.showRepairDetails = true;
                  this.gsxRepairs.hd = result.repair_hd[0];
                  this.gsxRepairs.dt = result.repair_dt;
                  for (let i = 0; i < this.gsxRepairs.dt.length; i++) {
                    if (this.gsxRepairs.dt[0].from_consigned === '0') {
                      this.gsxRepairs.dt[0].from_consigned = 'False';
                    } else {
                      this.gsxRepairs.dt[0].from_consigned = 'True';
                    }
                  }
                } else {
                  this.simpleAlert = {title: 'GSX Repair', msg: result.message};
                  this.openModal(simple_alert_temp);
                }
              }); */
  }

  getBlueDartData(trackNumber, blueDart_details: TemplateRef<any>) {
    this.buttonSpin = true;
    let result: any;
    this.dataService.gerBlueDartTracking(trackNumber).subscribe(
      data => {
        result = data;
        if (result.status === true) {
          this.blueDartResult = this.sanitizer.sanitize(SecurityContext.HTML, result.response[0]);
          this.openModal(blueDart_details);
        } else {
          alert(result.message);
        }
        this.buttonSpin = false;
      });
  }

  /* ******************* Service Report ******************* */

  fetchRepairDetails(simple_alert_temp: TemplateRef<any>, confirm_alert_temp: TemplateRef<any>) {
    this.buttonSpin = true;
    this.GSXParts(this.data.g_number, simple_alert_temp, confirm_alert_temp);
  }

  getGSX(event, simple_alert_temp: TemplateRef<any>,  confirm_alert_temp: TemplateRef<any>) {
    if ((event.keyCode === 13) || (event.keyCode === 9)) {
      this.GSXParts(event.target.value, simple_alert_temp , confirm_alert_temp);
    }
  }

  GSXParts(repairID, simple_alert_temp: TemplateRef<any>, confirm_alert_temp: TemplateRef<any>) {
    this.sPartDetails = [];
    let result: any = [];
    let isKGB: any = false;
    let isMarkRepairCompleted: any = false;
    let isQp: any = false;
    if (repairID !== '') {
      this.dataService.getRepairDetails(repairID)
              .subscribe(
                (data) => {
                  result = data;
                  if ((this.data.product_family === 'Accessories') && (this.data.status === 'Mark Repair Complete')) {
                    const errorMsg = 'GSX Repair is not yet completed. Click Yes to Generate Service Report manually.';
                    this.confirmAlert = {id: 'SVC', title: 'Service Report', msg: errorMsg};
                    this.openModal(confirm_alert_temp);
                    this.buttonSpin = false;
                  } else {
                  if (result.status === true) {
                    this.repairDetails = result.repair_detail;
                    if (result.repair_detail.repairStatusCode === 'RFPU') { // SPCM
                      isMarkRepairCompleted = true;
                    }
                    if (result.repair_detail.coverageStatusCode === 'QP') {
                      isQp = true;
                    }
                    this.repairedParts = this.repairDetails.parts;
                    for (let i = 0; i < this.repairedParts.length; i++) {
                      if ((this.repairedParts[i].billable === true) || (isMarkRepairCompleted === true) || (isQp === true)) {
                        if (this.repairedParts[i].kgbDeviceDetail) {
                          this.isGSXError = false;
                          isKGB = true;
                          const sPart = {
                            serialNo: this.repairedParts[i].kgbDeviceDetail.identifiers.serial,
                            partNo: this.repairedParts[i].number,
                            partDetail: this.repairedParts[i].description
                          };
                          this.sPartDetails.push(sPart);
                        }
                      }
                    }
                    this.buttonSpin = false;
                    if ((isKGB === false) && (isMarkRepairCompleted === false) && (isQp === false)) {
                      this.sPartDetails = [];
                      this.simpleAlert = {title: 'Service Report', msg: 'GSX Repair is not yet completed.'};
                      this.openModal(simple_alert_temp);
                    } else {
                      this.showSVCForm = 'true';
                    }
                  } else {
                    const errorMsg = result.message + '.' + ' Click Yes to Generate Service Report manually.';
                    this.confirmAlert = {id: 'SVC', title: 'Service Report', msg: errorMsg};
                    this.openModal(confirm_alert_temp);
                    this.buttonSpin = false;
                  }
                }
      });
    } else {
      this.simpleAlert = {title: 'Service Report', msg: 'GSX Repair Id is Required'};
      this.openModal(simple_alert_temp);
    }
  }

  serviceTypeSelect(value) {
    this.serviceData.serviceType = value;
  }

  addServicePart(inputData) {
    if ((inputData.serialNo !== '') && (inputData.partNo !== '') && (inputData.partDetail !== '')) {
      this.sPartDetails.push(inputData);
      this.servicePartInput = [{serialNo: '', partNo: '', partDetail: ''}];
    }
  }

  deleterow(idx) {
    this.sPartDetails.splice(idx, 1);
  }

  getSVC(ticketId) {
    let result: any;
    this.dataService.getSVC(ticketId)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.isExistSvc =  true;
                  this.existSvc = result.svc_hd;
                  for (let i = 0; i < this.existSvc.length; i++) {
                    if (this.existSvc[i].status === 'Active') {
                      this.showSVCForm = 'null';
                      break;
                    } else {
                      this.showSVCForm = 'false';
                    }
                  }
                } else {
                  this.isExistSvc = false;
                  this.existSvc = [];
                  this.showSVCForm = 'false';
                }
    });
  }

  viewSVC() {
    const tab = window.open();
    this.dataService.showSVC(this.ticketId)
            .subscribe(
              data => {
                const fileUrl = URL.createObjectURL(data);
                tab.location.href = fileUrl;
              });
  }

  deleteSVC(svcId, delete_svc_temp: TemplateRef<any>) {
    this.deleteSvcId = svcId;
    this.openModal(delete_svc_temp);
  }

  deleteSvcConfirm(simple_alert_temp) {
    if (this.deleteSvcRemarks === '') {
      this.notfilled = true;
    } else {
      let result;
      this.dataService.deleteSVC(this.ticketId, this.deleteSvcId, this.deleteSvcRemarks)
            .subscribe(
              data => {
                result = data;
                if (result.status === true) {
                  this.getSVC(this.ticketId);
                  this.modalRef.hide();
                } else {
                  this.simpleAlert = {title: 'Service Report', msg: result.message};
                  this.openModal(simple_alert_temp);
                }
              });
    }
  }

  generatesvc(diagnosis, inputData, add_data, simple_alert_temp: TemplateRef<any>) {
    this.buttonSpin = true;
    let inputDataComplete = true;
    let sDataComplete = false;
    let reportData: any;

    if ((inputData.serialNo !== '') && (inputData.partNo !== '') && (inputData.partDetail !== '')) {
      this.sPartDetails.push(inputData);
      this.servicePartInput = [{serialNo: '', partNo: '', partDetail: ''}];
      inputDataComplete = true;
    } else {
      if (this.sPartDetails.length === 0) {
        inputDataComplete = false;
      }
    }

    if (this.gsxNo !== '' && this.serviceData.serviceType !== 'Select' && diagnosis !== '') {
      sDataComplete = true;
    } else {
      sDataComplete = false;
    }
    if (inputDataComplete === true && sDataComplete === true) {
      if (this.data.site_type_id === '2') {
        reportData = '&gsx_no=' + this.gsxNo + '&gsx_service_type=' + this.serviceData.serviceType + '&diagnosis=' +
        encodeURIComponent(diagnosis) + '&status_id=' + this.data.status_id + '&product_description=' + this.data.product_description +
                              '&condition_of_device=' + add_data.condition + '&upgrades=' + add_data.upgrade +
                              '&warranty_status=' + this.data.warranty_status + '&product_family=' + add_data.family +
                              '&service_type=' + add_data.serviceType + '&accessory_recieved=' + add_data.accessory;
        this.callGenerateSVC(reportData, simple_alert_temp);
      } else {
        reportData = '&gsx_no=' + this.gsxNo + '&gsx_service_type=' + this.serviceData.serviceType + '&diagnosis=' +
        encodeURIComponent(diagnosis) + '&status_id=' + this.data.status_id;
        this.callGenerateSVC(reportData, simple_alert_temp);
      }
    } else {
      this.simpleAlert = {title: 'Service Report', msg: 'Fill all mandatory fields'};
      this.openModal(simple_alert_temp);
    }
  }

  callGenerateSVC(reportData, simple_alert_temp: TemplateRef<any>) {
    let result: any;
      this.dataService.generateSVC(this.ticketId, reportData, this.sPartDetails)
              .subscribe(
                (data) => {
                  result = data;
                  if (result.status === true) {
                    this.sPartDetails = [];
                   this.getSVC(this.ticketId);
                   this.svcDiagnosis = '';
                   this.buttonSpin = false;
                  } else {
                    this.buttonSpin = false;
                    this.showSVCForm = 'false';
                    this.sPartDetails = [];
                    this.simpleAlert = {title: 'Create Repair', msg: result.message};
                    this.openModal(simple_alert_temp);
                  }
      });
  }

  /************ Analysis **************/

  updateAnalysis(analysis) {
    let result: any;
    this.dataService.uploadAnalysis(this.ticketId, analysis)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.analysisText = '';
                  this.getAnalysis(this.ticketId);
                  this.gettimelinedata(this.ticketId);
                }
    });
  }

  getAnalysis(ticketId) {
    let result: any;
    this.dataService.getAnalysis(ticketId)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.analysisList = result.analysis;
                } else {
                  this.analysisList = [];
                }

    });
  }

  viewRaf() {
    const tab = window.open();
    this.dataService.viewRaf(this.ticketId)
      .subscribe(
        data => {
          const fileUrl = URL.createObjectURL(data);
          tab.location.href = fileUrl;
    });
  }

  /************ Payments **************/

  getPaymentDetails() {
    const raf_id = this.data.branch_code + this.data.id;
    let result: any;
    this.dataService.getPaymentDetails(raf_id, this.data.ticket_date)
    .subscribe(
      (data) => {
        result = data;
        if (result.status === true) {
          if (result.advance === false) {
            this.isAdvance = false;
          } else {
            this.isAdvance = true;
            this.paymentAdvance = result.advance;
            this.paymentAdvance.invoiceNoDate = this.paymentAdvance.caminvno + '/' + this.paymentAdvance.damindate;
          }
          if (result.invoice === false) {
            this.isInvoice = false;
          } else {
            this.isInvoice = true;
            this.paymentInvoice = result.invoice;
            this.paymentInvoice.invoiceNoDate = this.paymentInvoice.caminvno + '/' + this.paymentInvoice.damindate;
          }
        } else {
          this.isAdvance = false;
          this.isInvoice = false;
        }
    });
  }

  /************ CC Updates **************/

  ccUpdateAnalysis(analysis) {
    let result: any;
    this.dataService.uploadAnalysis(this.ticketId, analysis)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.ccAnalysisText = '';
                  this.ccGetAnalysis(this.ticketId);
                  this.getAnalysis(this.ticketId);
                  this.gettimelinedata(this.ticketId);
                }
    });
  }

  ccGetAnalysis(ticketId) {
    let result: any;
    this.dataService.getAnalysis(ticketId)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.ccAnalysisList = result.analysis;
                } else {
                  this.ccAnalysisList = [];
                }

    });
  }

   /************ CC Enquiry **************/

   getEnquiry(ticketId) {
    let result: any;
    this.dataService.getEnquiry(ticketId)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.EnquiryList = result.enquiry;
                } else {
                  this.EnquiryList = [];
                }

    });
  }

  /************ getMessage **************/

  getMessage(ticketId) {
    let result: any;
    this.dataService.getMessage(ticketId)
            .subscribe(
              (data) => {
                result = data;
                if (result.status === true) {
                  this.messageList = result.message;
                } else {
                  this.messageList = [];
                }
    });
  }
}
