import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TicketdetailRoutingModule } from './ticketdetail-routing.module';

import { DashboardService } from '../dashboard.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TicketdetailRoutingModule,
    TabsModule,
    FormsModule,
  ],
  providers: [DashboardService]
})
export class TicketdetailModule { }
